/***
 * @author Domenico Gigante [reloadlab.it]
 * @version 1.0
 ***/

// agordi CKeditor-lingvon
CKEDITOR.plugins.setLang('bootstrapMediaEmbed', 'eo', {
    toolbar: 'Enkorpigi aŭdvidaĵon',
    dialogTitle: 'Enkorpigi aŭdvidaĵon',
    dialogRatio: 'Elektu aŭdvidaĵan bildformaton',
	selectRatio: [
		'Origina grandeco',
		'Proporcio 21:9',
		'Proporcio 16:9',
		'Proporcio 4:3',
		'Proporcio 1:1'
	],
    dialogArea: 'Algluu la enkorpigan kodon ĉi tie'
});
